Summary:

	This folder contains batch files and powershell files that were created for the purpose of automating the computer 
Sanitization process solely for use by Application Administrators in the IT department of PPD-Thermofisher. 

Software Location:

	\\labs\madison\shared\BAM\Projects_Misc (Copy & Paste the full_cleanup_proj folder to local desktop.)
Instructions:

	Copy and Paste entire file found at the location above, to the desktop of the PC about to be sanitized. Then follow the instructions below:

	Navigate to one of the PowerShell files (Not Batch files) and right-click on it. Select the "Open With..." option. Next, select "Choose Another App". Navigate to the following location: C:\Windows\System32\WindowsPowerShell\v1.0, and select PowerShell.
Then check the box that says "Always use this app to open .ps1 files" and proceed below. 

	Copy and Paste entire file found at the location above, to the desktop of the PC about to be sanitized. Then follow the instructions below:

	Run batchfiles in sequential order. i.e. Run "~full_cleanup_1.1 Launcher.bat" first. After "~full_cleanup_1.1 Launcher.bat" has finished running, 
proceed to run "~full_cleanup_1.2 Launcher.bat", etc...

___________________________________________________________________________________________________________________________________________

Creator: Blake Marshall, Associate Application Administrator II; BAM 15FEB2023
Reports to: Zachary Hilliger, Associate Manager IT